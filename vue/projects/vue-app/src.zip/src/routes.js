import Home from './components/Home'
import Test from './components/Test'
export default[
    {path:"/",component:Home},
    {path:"/test",component:Test}

  ]