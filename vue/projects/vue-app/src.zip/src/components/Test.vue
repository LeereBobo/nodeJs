<template>
  <div id="test">
      <h1>Hello TEST</h1>
  </div>
</template>

<script>


export default {
  name: 'test',
  
  data(){
  	return{
  		
  	}
  },
  methods:{
  	
  }
  
}
</script>

<style scoped>
  
</style>

